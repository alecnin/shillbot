
from mothership.base import MothershipServer


if __name__ == "__main__":
    server = MothershipServer()
    server.run()

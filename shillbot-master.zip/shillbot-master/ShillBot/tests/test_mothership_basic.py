
import unittest

from mothership.base import MothershipServer


class TestMothershipBasic(unittest.TestCase):
    pass
